
 User Name : <?php echo $_POST['username']; ?><br>

 First Name : <?php echo $_POST['firstname']; ?><br>
 Last Name : <?php echo $_POST['lastname']; ?><br>
 Email : <?php echo $_POST['text1']; ?><br>
 Gender : <?php echo $_POST['gender']; ?><br>
 Password : <?php echo $_POST['psw']; ?><br>


